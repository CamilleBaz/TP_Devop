package com.epf.MatchMyBottle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MatchMyBottleApplication {

	public static void main(String[] args) {
		SpringApplication.run(MatchMyBottleApplication.class, args);
	}

}
