package com.epf.MatchMyBottle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MatchMyBottleApplicationTests {

	@Test
	void contextLoads() {
	}

}
